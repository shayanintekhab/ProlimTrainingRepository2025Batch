package com.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductAndOrdersRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductAndOrdersRestApiApplication.class, args);
	}

}
